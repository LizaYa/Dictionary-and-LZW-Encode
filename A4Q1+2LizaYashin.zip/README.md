# A4Q1LizaYashin
Part 1- how to run
1) Go to the directory where you saved the program and type on the command line 'Node Tests.js'
2) Note: on my computer only 'Node' worked.

Part2 - how to run
1) Go to the directory where you saved the program and make sure the text file you want to encode is in the sae directory.
2) Type 'Node Main.js <name of the file>.txt and press enter.
3) To decode back, type 'javac Decoder.java', press enter.
4) Type 'java Decoder.java <name of the file>.txt.ZLW' and press enter.
5) Now you can see in the directory the files.


