 //-----------------------------------------
     // NAME		: Yelizaveta Yashin
     // STUDENT NUMBER	: 7874435
     // COURSE		: COMP 2150
     // INSTRUCTOR	: Mike Domaratzk
     // ASSIGNMENT	: assignment #4
     // QUESTION	: question #2     
     // 
     // REMARKS: creates an Encoder objects.
     //
     //
     //-----------------------------------------
'use strict'
let Encoder = require('./Encoder');

function Main() {
    let encoder = new Encoder();
}

Main()